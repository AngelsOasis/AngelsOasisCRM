export default function Settings() {
  return (
    <div>
      <h1 className="font-serif text-3xl">Settings</h1>
      <p className="mt-1 text-plum/60">API keys, sending domain, roles, and notifications.</p>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="card">
          <h2 className="font-serif text-lg">API Keys & Integrations</h2>
          <p className="mt-2 text-sm text-plum/60">
            Secret keys are never entered here in the frontend — this screen is a placeholder pointing at
            where they actually live. Wire this page up to a small admin-only Edge Function if you want a
            real in-app "paste key, see masked value" flow; until then, set secrets directly:
          </p>
          <pre className="mt-3 overflow-x-auto rounded-lg bg-plum/5 p-3 text-xs text-plum-dark">
{`supabase secrets set DEEPSEEK_API_KEY=sk-...
supabase secrets set DEEPSEEK_API_KEY_FALLBACK=sk-...
supabase secrets set EMAIL_PROVIDER_API_KEY=...`}
          </pre>
          <p className="mt-3 text-xs text-plum/40">
            The Supabase URL and publishable key are the only values that belong in <code>.env.local</code> /
            your hosting provider's frontend env vars — see the README.
          </p>
        </div>

        <div className="card">
          <h2 className="font-serif text-lg">Sending domain</h2>
          <p className="mt-2 text-sm text-plum/60">
            From / reply-to address for all three campaigns: <strong>angelsoasis@proton.me</strong>
          </p>
          <p className="mt-2 text-xs text-plum/40">
            Confirm SPF/DKIM records are set up for this domain with your email provider so campaign mail
            doesn't land in spam.
          </p>
        </div>

        <div className="card">
          <h2 className="font-serif text-lg">User roles</h2>
          <p className="mt-2 text-sm text-plum/60">
            Roles live on the <code>profiles</code> table (<code>admin</code>, <code>approver</code>,{" "}
            <code>staff</code>, <code>viewer</code>). Only <code>admin</code>/<code>approver</code> should be
            able to approve campaigns — enforce this with a Row Level Security policy on{" "}
            <code>campaigns</code> once your roles are finalized.
          </p>
        </div>

        <div className="card">
          <h2 className="font-serif text-lg">Notifications</h2>
          <p className="mt-2 text-sm text-plum/60">
            Each profile has a <code>notify_on_pending_approval</code> flag. Hook it up to your email
            provider or a Slack webhook from the same Edge Function that creates a new draft.
          </p>
        </div>
      </div>
    </div>
  );
}
