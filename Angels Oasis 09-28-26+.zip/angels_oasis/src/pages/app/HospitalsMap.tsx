import { useEffect, useMemo, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Circle } from "react-leaflet";
import L from "leaflet";
import { supabase } from "../../lib/supabaseClient";
import { milesBetween } from "../../lib/geo";
import type { Facility, Lead } from "../../lib/types";

const RADII = [5, 10, 25, 50] as const;

// Shades of plum, black, and gray only — kept distinguishable for the map
// legend without introducing a color outside the white/plum/black palette.
const CATEGORY_COLOR: Record<string, string> = {
  hospital: "#0A0A0A",
  skilled_nursing_facility: "#4A1D3D",
  rehab_center: "#6B2C56",
  case_manager: "#2E1226",
  discharge_planner: "#8A8A8A",
  physician: "#1F1F1F",
  insurance_network: "#3D3D3D",
  healthcare_organization: "#B0B0B0",
};

function markerIcon(color: string) {
  return L.divIcon({
    className: "",
    html: `<div style="background:${color};width:14px;height:14px;border-radius:9999px;border:2px solid white;box-shadow:0 0 0 1px rgba(0,0,0,0.2)"></div>`,
    iconSize: [14, 14],
  });
}

export default function HospitalsMap() {
  const [facilities, setFacilities] = useState<Facility[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedFacility, setSelectedFacility] = useState<string>("");
  const [radius, setRadius] = useState<number>(25);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

  useEffect(() => {
    async function load() {
      const [{ data: facilityRows }, { data: leadRows }] = await Promise.all([
        supabase.from("facilities").select("*").eq("status", "open"),
        supabase.from("leads").select("*").not("latitude", "is", null).not("longitude", "is", null),
      ]);
      const openFacilities = (facilityRows as Facility[]) ?? [];
      setFacilities(openFacilities);
      setSelectedFacility(openFacilities[0]?.id ?? "");
      setLeads((leadRows as Lead[]) ?? []);
    }
    load();
  }, []);

  const center = useMemo(() => {
    const f = facilities.find((f) => f.id === selectedFacility);
    return f && f.latitude && f.longitude ? [f.latitude, f.longitude] : [34.1614, -118.3942];
  }, [facilities, selectedFacility]);

  const visibleLeads = useMemo(() => {
    return leads.filter((lead) => {
      if (!lead.latitude || !lead.longitude) return false;
      const d = milesBetween(center[0], center[1], lead.latitude, lead.longitude);
      return d <= radius;
    });
  }, [leads, center, radius]);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl">Hospitals Map</h1>
          <p className="mt-1 text-plum/60">Nearby hospitals, SNFs, rehab centers, and healthcare partners.</p>
        </div>
        <div className="flex items-center gap-3">
          <select className="rounded-lg border border-plum/20 px-3 py-2 text-sm"
            value={selectedFacility} onChange={(e) => setSelectedFacility(e.target.value)}>
            {facilities.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
          </select>
          <div className="flex overflow-hidden rounded-lg border border-plum/20">
            {RADII.map((r) => (
              <button key={r} onClick={() => setRadius(r)}
                className={`px-3 py-2 text-sm ${radius === r ? "bg-plum text-white" : "bg-white text-plum"}`}>
                {r} mi
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 h-[520px] overflow-hidden rounded-2xl border border-plum/10">
          <MapContainer center={center as [number, number]} zoom={9} style={{ height: "100%", width: "100%" }}>
            <TileLayer
              attribution='&copy; OpenStreetMap contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Circle center={center as [number, number]} radius={radius * 1609.34}
              pathOptions={{ color: "#4A1D3D", fillOpacity: 0.05 }} />
            {visibleLeads.map((lead) => (
              <Marker
                key={lead.id}
                position={[lead.latitude!, lead.longitude!]}
                icon={markerIcon(CATEGORY_COLOR[lead.category] ?? "#4A1D3D")}
                eventHandlers={{ click: () => setSelectedLead(lead) }}
              >
                <Popup>
                  <strong>{lead.facility_name}</strong>
                  <br />
                  {lead.category.replaceAll("_", " ")}
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>

        <div className="card">
          <h2 className="font-serif text-xl">Facility details</h2>
          {!selectedLead && <p className="mt-3 text-sm text-plum/60">Click a marker to see contact info and outreach history.</p>}
          {selectedLead && (
            <div className="mt-3 space-y-2 text-sm">
              <p className="font-semibold">{selectedLead.facility_name}</p>
              <p className="text-plum/60">{selectedLead.address}</p>
              <p className="capitalize text-plum/60">{selectedLead.category.replaceAll("_", " ")} · {selectedLead.county}</p>
              <hr className="my-2 border-plum/10" />
              <p><span className="text-plum/50">Contact:</span> {selectedLead.contact_person || "—"}</p>
              <p><span className="text-plum/50">Email:</span> {selectedLead.email || "—"}</p>
              <p><span className="text-plum/50">Phone:</span> {selectedLead.phone || "—"}</p>
              <p><span className="text-plum/50">Status:</span> {selectedLead.status.replaceAll("_", " ")}</p>
              <p className="text-xs text-plum/40">
                Outreach history and per-email status pull from the <code>emails</code> table, filtered by lead_id
                (wire up once the Campaigns send job is generating real sends).
              </p>
            </div>
          )}
          <p className="mt-4 text-xs text-plum/40">
            Radius search here filters leads already in your database. To auto-discover new facilities near a
            location, swap the tile layer for the Google Places API (or another maps/places provider) and write
            results into <code>leads</code> with <code>source = 'map_discovery'</code>.
          </p>
        </div>
      </div>
    </div>
  );
}
