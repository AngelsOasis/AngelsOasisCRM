import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabaseClient";
import { useAuth } from "../../lib/auth";
import type { Campaign, ContentDraft } from "../../lib/types";

const STATUS_LABEL: Record<Campaign["approval_status"], string> = {
  pending_approval: "Pending Approval",
  approved: "Approved",
  rejected: "Rejected",
  needs_edit: "Needs Edit",
};

const STATUS_COLOR: Record<Campaign["approval_status"], string> = {
  pending_approval: "bg-amber-100 text-amber-800",
  approved: "bg-ink text-white",
  rejected: "bg-red-100 text-red-700",
  needs_edit: "bg-plum/10 text-plum",
};

export default function Campaigns() {
  const { session } = useAuth();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [drafts, setDrafts] = useState<Record<string, ContentDraft>>({});
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const { data: campaignRows } = await supabase
      .from("campaigns")
      .select("*")
      .order("send_date", { ascending: true });
    const campaignsData = (campaignRows as Campaign[]) ?? [];
    setCampaigns(campaignsData);

    if (campaignsData.length) {
      const { data: draftRows } = await supabase
        .from("content_drafts")
        .select("*")
        .in("campaign_id", campaignsData.map((c) => c.id));
      const byCampaign: Record<string, ContentDraft> = {};
      (draftRows as ContentDraft[] | null)?.forEach((d) => (byCampaign[d.campaign_id] = d));
      setDrafts(byCampaign);
    }
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function approve(id: string) {
    await supabase
      .from("campaigns")
      .update({ approval_status: "approved", approved_by: session?.user.id, approved_at: new Date().toISOString() })
      .eq("id", id);
    load();
  }

  async function reject(id: string) {
    const reason = prompt("Reason for rejecting (optional):") ?? "";
    await supabase.from("campaigns").update({ approval_status: "rejected", rejection_reason: reason }).eq("id", id);
    load();
  }

  async function requestEdit(id: string) {
    await supabase.from("campaigns").update({ approval_status: "needs_edit" }).eq("id", id);
    load();
  }

  const pending = campaigns.filter((c) => c.approval_status === "pending_approval" || c.approval_status === "needs_edit");
  const others = campaigns.filter((c) => c.approval_status === "approved" || c.approval_status === "rejected");

  return (
    <div>
      <h1 className="font-serif text-3xl">Campaigns</h1>
      <p className="mt-1 text-plum/60">
        Drafts are created automatically by the time-triggered AI Writer job. Nothing sends until it's approved here.
      </p>

      <h2 className="mt-8 font-serif text-xl">Pending your review</h2>
      {loading && <p className="mt-3 text-sm text-plum/50">Loading…</p>}
      {!loading && pending.length === 0 && (
        <p className="mt-3 text-sm text-plum/50">Nothing waiting on approval right now.</p>
      )}
      <div className="mt-3 space-y-4">
        {pending.map((c) => {
          const draft = drafts[c.id];
          return (
            <div key={c.id} className="card">
              <div className="flex items-start justify-between">
                <div>
                  <span className={`badge ${STATUS_COLOR[c.approval_status]}`}>{STATUS_LABEL[c.approval_status]}</span>
                  <h3 className="mt-2 font-serif text-lg">{c.title}</h3>
                  <p className="text-xs text-plum/50 capitalize">{c.day} · sends {c.send_date}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => approve(c.id)} className="btn-primary !px-3 !py-1.5 text-xs">Approve</button>
                  <button onClick={() => requestEdit(c.id)} className="rounded-full border border-plum/20 px-3 py-1.5 text-xs text-plum hover:bg-plum/5">
                    Needs edit
                  </button>
                  <button onClick={() => reject(c.id)} className="rounded-full border border-red-200 px-3 py-1.5 text-xs text-red-600 hover:bg-red-50">
                    Reject
                  </button>
                </div>
              </div>
              {draft ? (
                <div className="mt-4 rounded-xl bg-plum/5 p-4 text-sm">
                  <p className="font-semibold">{draft.subject}</p>
                  <p className="mt-2 whitespace-pre-wrap text-plum/80">{draft.body}</p>
                  {draft.cta && <p className="mt-2 font-medium text-plum">{draft.cta}</p>}
                </div>
              ) : (
                <p className="mt-3 text-xs text-plum/40">No draft generated yet — run the AI Writer for this campaign.</p>
              )}
            </div>
          );
        })}
      </div>

      <h2 className="mt-10 font-serif text-xl">History</h2>
      <div className="mt-3 overflow-hidden rounded-2xl border border-plum/10 bg-white">
        <table className="min-w-full divide-y divide-plum/10 text-sm">
          <thead className="bg-plum/5 text-left text-xs uppercase tracking-wide text-plum/60">
            <tr>
              <th className="px-4 py-3">Campaign</th>
              <th className="px-4 py-3">Day</th>
              <th className="px-4 py-3">Send date</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-plum/5">
            {others.map((c) => (
              <tr key={c.id}>
                <td className="px-4 py-3">{c.title}</td>
                <td className="px-4 py-3 capitalize">{c.day}</td>
                <td className="px-4 py-3">{c.send_date}</td>
                <td className="px-4 py-3"><span className={`badge ${STATUS_COLOR[c.approval_status]}`}>{STATUS_LABEL[c.approval_status]}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
