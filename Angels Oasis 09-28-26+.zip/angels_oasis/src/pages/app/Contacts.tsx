import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabaseClient";

interface ContactRow {
  id: string;
  name: string;
  title: string | null;
  email: string | null;
  phone: string | null;
  is_primary: boolean;
  leads: { facility_name: string } | null;
}

export default function Contacts() {
  const [contacts, setContacts] = useState<ContactRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("contacts")
      .select("id, name, title, email, phone, is_primary, leads(facility_name)")
      .then(({ data }) => {
        setContacts((data as unknown as ContactRow[]) ?? []);
        setLoading(false);
      });
  }, []);

  return (
    <div>
      <h1 className="font-serif text-3xl">Contacts</h1>
      <p className="mt-1 text-plum/60">Every named contact across your leads, in one place.</p>

      <div className="mt-6 overflow-hidden rounded-2xl border border-plum/10 bg-white">
        <table className="min-w-full divide-y divide-plum/10 text-sm">
          <thead className="bg-plum/5 text-left text-xs uppercase tracking-wide text-plum/60">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Facility</th>
              <th className="px-4 py-3">Title</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Phone</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-plum/5">
            {loading && <tr><td className="px-4 py-6 text-plum/50" colSpan={5}>Loading…</td></tr>}
            {!loading && contacts.length === 0 && (
              <tr><td className="px-4 py-6 text-plum/50" colSpan={5}>
                No contacts yet — add contacts from a lead's detail view on the Leads page.
              </td></tr>
            )}
            {contacts.map((c) => (
              <tr key={c.id}>
                <td className="px-4 py-3 font-medium">{c.name}{c.is_primary && <span className="ml-2 badge bg-ink text-white">Primary</span>}</td>
                <td className="px-4 py-3">{c.leads?.facility_name ?? "—"}</td>
                <td className="px-4 py-3">{c.title ?? "—"}</td>
                <td className="px-4 py-3">{c.email ?? "—"}</td>
                <td className="px-4 py-3">{c.phone ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
